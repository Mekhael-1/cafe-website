import { motion } from "framer-motion";

export default function MenuCard({ item }) {
  return (
    <motion.article
      layout
      initial={{ opacity: 0, scale: 0.92 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.92 }}
      transition={{ duration: 0.35 }}
      whileHover={{ y: -6 }}
      className="group overflow-hidden rounded-2xl bg-white shadow-sm transition-shadow hover:shadow-xl"
    >
      <div className="aspect-[4/3] overflow-hidden bg-latte">
        <img
          src={item.img}
          alt={item.name}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
      </div>
      <div className="p-5">
        <div className="flex items-start justify-between gap-3">
          <h3 className="font-serif text-xl sm:text-2xl">{item.name}</h3>
          <span className="whitespace-nowrap font-semibold text-caramel">{item.price} ج.م</span>
        </div>
        <p className="mt-2 text-sm text-espresso/70">{item.desc}</p>
      </div>
    </motion.article>
  );
}
