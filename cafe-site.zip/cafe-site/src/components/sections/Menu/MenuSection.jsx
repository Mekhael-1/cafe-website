import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { categories, menuItems } from "../../../data/menu";
import Container from "../../ui/Container";
import Reveal from "../../ui/Reveal";
import SectionTitle from "../../ui/SectionTitle";
import CategoryFilter from "./CategoryFilter";
import MenuCard from "./MenuCard";

export default function MenuSection() {
  const [active, setActive] = useState("الكل");

  const filtered = useMemo(
    () => (active === "الكل" ? menuItems : menuItems.filter((i) => i.category === active)),
    [active]
  );

  return (
    <section id="menu" className="bg-latte/40 py-16 md:py-24">
      <Container>
        <SectionTitle eyebrow="قائمتنا" title="نكهات تستحق التجربة" />

        <Reveal delay={0.1}>
          <CategoryFilter categories={categories} active={active} onChange={setActive} />
        </Reveal>

        <motion.div
          layout
          className="mt-10 grid grid-cols-1 gap-5 sm:grid-cols-2 sm:gap-6 lg:grid-cols-3 xl:grid-cols-4"
        >
          <AnimatePresence mode="popLayout">
            {filtered.map((item) => (
              <MenuCard key={item.id} item={item} />
            ))}
          </AnimatePresence>
        </motion.div>
      </Container>
    </section>
  );
}
