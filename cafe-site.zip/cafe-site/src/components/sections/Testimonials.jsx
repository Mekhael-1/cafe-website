import { Quote, Star } from "lucide-react";
import { testimonials } from "../../data/testimonials";
import Container from "../ui/Container";
import Reveal from "../ui/Reveal";
import SectionTitle from "../ui/SectionTitle";

export default function Testimonials() {
  return (
    <section id="testimonials" className="bg-roast py-16 md:py-24">
      <Container>
        <SectionTitle eyebrow="آراء الزبائن" title="ماذا قالوا عنا" light />
        <div className="grid gap-5 md:grid-cols-3 md:gap-6">
          {testimonials.map((t, i) => (
            <Reveal key={t.id} delay={i * 0.12}>
              <figure className="h-full rounded-2xl border border-cream/10 bg-cream/5 p-6 text-cream transition-colors hover:bg-cream/10">
                <Quote className="mb-4 text-caramel" size={28} />
                <blockquote className="leading-loose text-cream/85">{t.text}</blockquote>
                <div className="mt-4 flex gap-1 text-caramel" aria-label="5 نجوم">
                  {Array.from({ length: 5 }).map((_, k) => (
                    <Star key={k} size={16} fill="currentColor" />
                  ))}
                </div>
                <figcaption className="mt-4">
                  <p className="font-semibold">{t.name}</p>
                  <p className="text-sm text-cream/60">{t.role}</p>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
}
