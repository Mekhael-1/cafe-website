import Container from "../ui/Container";
import Reveal from "../ui/Reveal";
import SectionTitle from "../ui/SectionTitle";

const stats = [
  { value: "+12", label: "نوع بن مختص" },
  { value: "+5K", label: "زبون سعيد" },
  { value: "100%", label: "تحميص طازج" },
];

export default function About() {
  return (
    <section id="about" className="py-16 md:py-24">
      <Container>
        <div className="grid items-center gap-10 md:grid-cols-2 lg:gap-16">
          <Reveal>
            <div className="relative">
              <img
                src="/img/about.svg"
                alt="داخل الكافيه"
                loading="lazy"
                className="aspect-[4/5] w-full rounded-3xl object-cover shadow-xl"
              />
              <div className="absolute -bottom-6 -end-4 hidden rounded-2xl bg-caramel p-5 text-cream shadow-lg sm:block">
                <p className="font-serif text-3xl">منذ 2018</p>
                <p className="text-sm opacity-90">نصنع القهوة بحب</p>
              </div>
            </div>
          </Reveal>

          <div>
            <SectionTitle eyebrow="من نحن" title="مكان صُنع للقهوة والناس" className="md:text-start md:mb-6" />
            <Reveal delay={0.1}>
              <p className="leading-loose text-espresso/80">
                بدأت حكايتنا بشغف بسيط لقهوة مختصة بجودة عالية. نختار حبوبنا من مزارع موثوقة، ونحمّصها بأنفسنا، ونقدمها
                في مكان دافئ مصمم ليكون ملتقى الأصدقاء ومكتب الحالمين.
              </p>
            </Reveal>
            <div className="mt-8 grid grid-cols-3 gap-4">
              {stats.map((s, i) => (
                <Reveal key={s.label} delay={0.15 + i * 0.1}>
                  <div className="rounded-2xl bg-latte p-4 text-center">
                    <p className="font-serif text-2xl text-caramel sm:text-3xl">{s.value}</p>
                    <p className="mt-1 text-xs sm:text-sm">{s.label}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}
