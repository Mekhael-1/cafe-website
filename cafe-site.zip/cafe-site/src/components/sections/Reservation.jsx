import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { CheckCircle2 } from "lucide-react";
import Container from "../ui/Container";
import Reveal from "../ui/Reveal";
import SectionTitle from "../ui/SectionTitle";
import Button from "../ui/Button";

const field =
  "w-full min-h-11 rounded-xl border border-espresso/15 bg-white px-4 py-2.5 outline-none transition focus:border-caramel focus:ring-2 focus:ring-caramel/30";

export default function Reservation() {
  const [sent, setSent] = useState(false);
  const [data, setData] = useState({ name: "", phone: "", date: "", guests: "2" });

  const onChange = (e) => setData((d) => ({ ...d, [e.target.name]: e.target.value }));

  const onSubmit = (e) => {
    e.preventDefault();
    // TODO: اربط هذا الجزء بالـ API أو خدمة البريد (EmailJS / Formspree ...)
    console.log("Reservation:", data);
    setSent(true);
  };

  return (
    <section id="reservation" className="py-16 md:py-24">
      <Container>
        <div className="mx-auto max-w-2xl">
          <SectionTitle eyebrow="الحجز" title="احجز طاولتك الآن" />
          <Reveal delay={0.1}>
            <div className="rounded-3xl bg-latte/60 p-6 sm:p-10">
              <AnimatePresence mode="wait">
                {sent ? (
                  <motion.div
                    key="done"
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="py-10 text-center"
                  >
                    <CheckCircle2 className="mx-auto mb-4 text-sage" size={56} />
                    <h3 className="font-serif text-2xl">تم استلام طلبك!</h3>
                    <p className="mt-2 text-espresso/70">سنتواصل معك قريباً لتأكيد الحجز.</p>
                  </motion.div>
                ) : (
                  <motion.form
                    key="form"
                    onSubmit={onSubmit}
                    exit={{ opacity: 0 }}
                    className="grid gap-4 sm:grid-cols-2"
                  >
                    <label className="text-sm font-medium">
                      الاسم
                      <input required name="name" value={data.name} onChange={onChange} className={`${field} mt-1`} />
                    </label>
                    <label className="text-sm font-medium">
                      رقم الهاتف
                      <input required type="tel" name="phone" dir="ltr" value={data.phone} onChange={onChange} className={`${field} mt-1 text-end`} />
                    </label>
                    <label className="text-sm font-medium">
                      التاريخ
                      <input required type="date" name="date" value={data.date} onChange={onChange} className={`${field} mt-1`} />
                    </label>
                    <label className="text-sm font-medium">
                      عدد الأشخاص
                      <select name="guests" value={data.guests} onChange={onChange} className={`${field} mt-1`}>
                        {[1, 2, 3, 4, 5, 6, 8, 10].map((n) => (
                          <option key={n} value={n}>{n}</option>
                        ))}
                      </select>
                    </label>
                    <Button type="submit" variant="dark" className="mt-2 sm:col-span-2">
                      تأكيد الحجز
                    </Button>
                  </motion.form>
                )}
              </AnimatePresence>
            </div>
          </Reveal>
        </div>
      </Container>
    </section>
  );
}
