import { motion } from "framer-motion";
import Container from "../ui/Container";
import SectionTitle from "../ui/SectionTitle";
import Reveal from "../ui/Reveal";

const photos = [1, 2, 3, 4, 5, 6].map((n) => ({ id: n, src: `/img/gallery-${n}.svg`, alt: `صورة من الكافيه ${n}` }));
const spans = ["row-span-2", "", "", "row-span-2", "", ""];

export default function Gallery() {
  return (
    <section id="gallery" className="py-16 md:py-24">
      <Container>
        <SectionTitle eyebrow="المعرض" title="لحظات من مكاننا" />
        <div className="grid auto-rows-[10rem] grid-cols-2 gap-3 sm:auto-rows-[12rem] sm:gap-4 md:grid-cols-3 lg:auto-rows-[14rem]">
          {photos.map((p, i) => (
            <Reveal key={p.id} delay={(i % 3) * 0.08} className={`${spans[i]} overflow-hidden rounded-2xl`}>
              <motion.img
                src={p.src}
                alt={p.alt}
                loading="lazy"
                whileHover={{ scale: 1.08 }}
                transition={{ duration: 0.5 }}
                className="h-full w-full object-cover"
              />
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
}
