import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowDown, Coffee } from "lucide-react";
import Button from "../ui/Button";
import Container from "../ui/Container";

const container = { hidden: {}, show: { transition: { staggerChildren: 0.12, delayChildren: 0.2 } } };
const item = {
  hidden: { opacity: 0, y: 30 },
  show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] } },
};

export default function Hero() {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const bgY = useTransform(scrollYProgress, [0, 1], ["0%", "30%"]);
  const contentY = useTransform(scrollYProgress, [0, 1], ["0%", "15%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);

  return (
    <section id="top" ref={ref} className="relative flex min-h-[100svh] items-center overflow-hidden bg-latte">
      {/* خلفية بارالاكس */}
      <motion.div style={{ y: bgY }} className="absolute inset-0 -z-0" aria-hidden>
        <div className="absolute -top-24 -start-24 size-72 rounded-full bg-caramel/20 blur-3xl md:size-[28rem]" />
        <div className="absolute -bottom-24 -end-24 size-80 rounded-full bg-terracotta/20 blur-3xl md:size-[32rem]" />
      </motion.div>

      <Container className="relative z-10 pb-16 pt-28 md:pt-32">
        <motion.div style={{ y: contentY, opacity }} className="grid items-center gap-12 md:grid-cols-2">
          <motion.div variants={container} initial="hidden" animate="show" className="text-center md:text-start">
            <motion.p variants={item} className="mb-4 text-sm font-semibold tracking-widest text-terracotta">
              ☕ محمصة طازجة كل يوم
            </motion.p>
            <motion.h1 variants={item} className="font-serif text-[clamp(2.6rem,7vw,5.5rem)] leading-[1.1]">
              لكل فنجان <span className="text-caramel">حكاية</span> تستحق أن تُروى
            </motion.h1>
            <motion.p variants={item} className="mx-auto mt-6 max-w-lg text-base text-espresso/75 md:mx-0 md:text-lg">
              نحمّص حبوبنا بعناية ونقدمها لك في أجواء دافئة وعصرية. تعال واستمتع بقهوتك كما يجب.
            </motion.p>
            <motion.div variants={item} className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row md:justify-start">
              <Button href="#menu" variant="dark">استكشف القائمة</Button>
              <Button href="#reservation" variant="outline">احجز طاولة</Button>
            </motion.div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.9, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="relative mx-auto aspect-square w-full max-w-xs sm:max-w-sm lg:max-w-md"
          >
            <div className="absolute inset-0 rounded-full bg-espresso" />
            <div className="absolute inset-4 rounded-full border border-caramel/40" />
            <motion.div
              animate={{ y: [0, -14, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="absolute inset-0 flex items-center justify-center text-caramel"
            >
              <Coffee strokeWidth={1.2} className="size-1/2" />
            </motion.div>
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
              className="absolute inset-0"
              aria-hidden
            >
              <span className="absolute start-1/2 -top-2 size-5 rounded-full bg-terracotta" />
            </motion.div>
          </motion.div>
        </motion.div>
      </Container>

      <motion.a
        href="#about"
        aria-label="انزل للأسفل"
        animate={{ y: [0, 8, 0] }}
        transition={{ duration: 1.8, repeat: Infinity }}
        className="absolute bottom-6 start-1/2 hidden -translate-x-1/2 text-espresso/60 sm:block"
      >
        <ArrowDown />
      </motion.a>
    </section>
  );
}
