import { Coffee, Instagram, Facebook, MapPin, Phone, Clock } from "lucide-react";
import { navLinks } from "../../data/links";
import Container from "../ui/Container";

export default function Footer() {
  return (
    <footer className="bg-roast pb-8 pt-14 text-cream/80">
      <Container>
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <a href="#top" className="mb-4 flex items-center gap-2 font-serif text-2xl font-bold text-cream">
              <Coffee className="text-caramel" size={26} /> بن وحكاية
            </a>
            <p className="text-sm leading-relaxed">قهوة محمصة بعناية، ومخبوزات طازجة، ومكان يشبهك.</p>
          </div>

          <div>
            <h3 className="mb-4 font-semibold text-cream">روابط سريعة</h3>
            <ul className="space-y-2 text-sm">
              {navLinks.map((l) => (
                <li key={l.href}>
                  <a href={l.href} className="transition-colors hover:text-caramel">{l.label}</a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="mb-4 font-semibold text-cream">تواصل معنا</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-2"><MapPin size={16} className="text-caramel" /> الإسكندرية، شارع الكورنيش</li>
              <li className="flex items-center gap-2"><Phone size={16} className="text-caramel" /> <span dir="ltr">+20 100 000 0000</span></li>
              <li className="flex items-center gap-2"><Clock size={16} className="text-caramel" /> يومياً 8 ص – 12 م</li>
            </ul>
          </div>

          <div>
            <h3 className="mb-4 font-semibold text-cream">تابعنا</h3>
            <div className="flex gap-3">
              {[Instagram, Facebook].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  aria-label="رابط التواصل الاجتماعي"
                  className="flex size-11 items-center justify-center rounded-full border border-cream/20 transition-colors hover:border-caramel hover:bg-caramel"
                >
                  <Icon size={18} />
                </a>
              ))}
            </div>
          </div>
        </div>

        <p className="mt-12 border-t border-cream/10 pt-6 text-center text-xs">
          © {new Date().getFullYear()} بن وحكاية. جميع الحقوق محفوظة.
        </p>
      </Container>
    </footer>
  );
}
