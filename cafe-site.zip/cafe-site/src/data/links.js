export const navLinks = [
  { href: "#about", label: "من نحن" },
  { href: "#menu", label: "القائمة" },
  { href: "#gallery", label: "المعرض" },
  { href: "#testimonials", label: "آراء الزبائن" },
  { href: "#reservation", label: "احجز طاولة" },
];
