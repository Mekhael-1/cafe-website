export const categories = ["الكل", "قهوة ساخنة", "قهوة باردة", "مخبوزات", "حلويات"];

export const menuItems = [
  { id: 1, name: "إسبريسو", category: "قهوة ساخنة", price: 45, desc: "تحميص داكن بنكهة غنية ومركّزة", img: "/img/espresso.svg" },
  { id: 2, name: "فلات وايت", category: "قهوة ساخنة", price: 65, desc: "إسبريسو مزدوج مع حليب مخملي", img: "/img/flat-white.svg" },
  { id: 3, name: "آيس لاتيه", category: "قهوة باردة", price: 70, desc: "منعش مع ثلج وحليب بارد", img: "/img/iced-latte.svg" },
  { id: 4, name: "كولد برو", category: "قهوة باردة", price: 75, desc: "منقوع على البارد لمدة 18 ساعة", img: "/img/cold-brew.svg" },
  { id: 5, name: "كرواسون زبدة", category: "مخبوزات", price: 55, desc: "هش من الخارج وطري من الداخل، طازج كل صباح", img: "/img/croissant.svg" },
  { id: 6, name: "تشيز كيك", category: "حلويات", price: 90, desc: "قاعدة بسكويت مع صوص التوت الطازج", img: "/img/cheesecake.svg" },
];
